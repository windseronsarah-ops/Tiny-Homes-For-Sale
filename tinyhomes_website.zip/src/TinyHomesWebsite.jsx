/* Tiny Homes Website React Component */
import React, { useState } from "react";

export default function TinyHomesWebsite() {
  return <div className="p-10 text-2xl">Tiny Homes Website Ready</div>;
}
