/* Tiny Homes Website - Upgraded
Includes:
- WhatsApp floating CTA
- Booking form (Formspree placeholder)
- Pricing grid
- Photo gallery carousel (vanilla JS)
- Testimonials carousel (vanilla JS)
- Rent-to-own page (route)
- SEO meta tags (index.html updated)
- Google Maps embed
- Dark mode toggle (tailwind-based)
Notes:
- This is a front-end only demo. Hook form action to Formspree or your backend.
- Install dependencies and run: npm install && npm run dev
*/

import React, { useEffect, useState, useRef } from "react";
import { FaPhone, FaWhatsapp, FaSun, FaMoon } from "react-icons/fa";

export default function TinyHomesWebsite() {
  const [dark, setDark] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [route, setRoute] = useState(window.location.hash.replace("#","") || "home");
  const galleryRef = useRef(null);
  const testimonialsRef = useRef(null);

  useEffect(() => {
    // sync dark mode class on html
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  useEffect(() => {
    function onHash() {
      setRoute(window.location.hash.replace("#","") || "home");
      window.scrollTo({top:0,behavior:"smooth"});
    }
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  },[]);

  // Simple auto-advance for testimonials
  useEffect(() => {
    const el = testimonialsRef.current;
    if(!el) return;
    let idx = 0;
    const items = el.querySelectorAll(".testimonial-item");
    function show(i){
      items.forEach((it, j) => it.style.display = j===i ? "block" : "none");
    }
    show(idx);
    const t = setInterval(()=> {
      idx = (idx+1) % items.length;
      show(idx);
    },4000);
    return ()=> clearInterval(t);
  },[route]);

  // Simple gallery slider prev/next
  function galleryNext(dir=1){
    const el = galleryRef.current;
    if(!el) return;
    const items = el.querySelectorAll(".gallery-item");
    if(items.length===0) return;
    let idx = [...items].findIndex(it => it.classList.contains("visible"));
    if(idx===-1) idx=0;
    items[idx].classList.remove("visible");
    idx = (idx+dir+items.length)%items.length;
    items[idx].classList.add("visible");
  }

  // Booking form submit handler (front-end demo)
  function handleBooking(e){
    e.preventDefault();
    const fm = new FormData(e.target);
    // For demo, we'll just log and show an alert.
    console.log(Object.fromEntries(fm.entries()));
    alert("Booking request sent! We'll contact you soon.");
    e.target.reset();
  }

  const Gallery = () => (
    <section id="gallery" className="py-12">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-2xl font-bold mb-6">Photo Gallery</h2>
        <div className="relative">
          <div ref={galleryRef} className="overflow-hidden rounded-lg shadow">
            <div className="gallery-item visible"><img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1400&auto=format&fit=crop" className="w-full h-80 object-cover" /></div>
            <div className="gallery-item"><img src="https://images.unsplash.com/photo-1505691723518-36a43f3a5d9b?q=80&w=1400&auto=format&fit=crop" className="w-full h-80 object-cover" /></div>
            <div className="gallery-item"><img src="https://images.unsplash.com/photo-1477090951336-5c79f3d9a4d6?q=80&w=1400&auto=format&fit=crop" className="w-full h-80 object-cover" /></div>
          </div>

          <div className="absolute left-3 top-1/2 -translate-y-1/2">
            <button onClick={()=>galleryNext(-1)} className="bg-white/90 p-2 rounded-full shadow">‹</button>
          </div>
          <div className="absolute right-3 top-1/2 -translate-y-1/2">
            <button onClick={()=>galleryNext(1)} className="bg-white/90 p-2 rounded-full shadow">›</button>
          </div>
        </div>
      </div>
    </section>
  );

  const Testimonials = () => (
    <section id="testimonials" className="py-12 bg-gray-50 dark:bg-gray-800">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <h2 className="text-2xl font-bold mb-6">What our customers say</h2>
        <div ref={testimonialsRef} className="relative">
          <div className="testimonial-item p-6 bg-white rounded-lg shadow mb-4">
            <p>“We rent our tiny home on Airbnb and it's been a money-maker — guests love the design.”</p>
            <div className="mt-3 font-semibold">— Amina, Douala</div>
          </div>
          <div className="testimonial-item p-6 bg-white rounded-lg shadow mb-4" style={{display:"none"}}>
            <p>“Excellent build quality and fast delivery. Support was helpful with setup.”</p>
            <div className="mt-3 font-semibold">— Mark, Yaoundé</div>
          </div>
          <div className="testimonial-item p-6 bg-white rounded-lg shadow mb-4" style={{display:"none"}}>
            <p>“Custom finishes look amazing — exactly what we wanted for our retreat property.”</p>
            <div className="mt-3 font-semibold">— Linda, Kribi</div>
          </div>
        </div>
      </div>
    </section>
  );

  const Pricing = ()=> (
    <section id="pricing" className="py-12">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-2xl font-bold mb-6">Pricing & Options</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="p-6 bg-white rounded-lg shadow">
            <h3 className="font-semibold">Starter</h3>
            <div className="text-indigo-600 text-2xl font-extrabold mt-3">$15,000</div>
            <p className="text-sm text-gray-600 mt-2">Basic shell, insulation, wiring.</p>
            <button className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded" onClick={()=>window.location.hash="contact"}>Request Quote</button>
          </div>
          <div className="p-6 bg-white rounded-lg shadow">
            <h3 className="font-semibold">Deluxe</h3>
            <div className="text-indigo-600 text-2xl font-extrabold mt-3">$22,000</div>
            <p className="text-sm text-gray-600 mt-2">Finishes, plumbing, optional loft.</p>
            <button className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded" onClick={()=>window.location.hash="contact"}>Request Quote</button>
          </div>
          <div className="p-6 bg-white rounded-lg shadow">
            <h3 className="font-semibold">Luxury</h3>
            <div className="text-indigo-600 text-2xl font-extrabold mt-3">$35,000</div>
            <p className="text-sm text-gray-600 mt-2">Premium finishes, appliances, customization.</p>
            <button className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded" onClick={()=>window.location.hash="contact"}>Request Quote</button>
          </div>
        </div>

        <div className="mt-8">
          <h4 className="font-semibold mb-2">Rent-to-Own</h4>
          <p className="text-sm text-gray-600">Ask about our rent-to-own plans: low down payment, monthly terms tailored to you. <a className="text-indigo-600" href="#rent-to-own" onClick={(e)=>{e.preventDefault(); window.location.hash='rent-to-own'}}>Learn more</a></p>
        </div>
      </div>
    </section>
  );

  const BookingForm = ()=> (
    <section id="contact" className="py-12 bg-indigo-600 text-white">
      <div className="max-w-4xl mx-auto px-6 grid md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-bold">Request a quote or book a consultation</h2>
          <p className="mt-3 text-indigo-100">Tell us about your project and preferred timeline.</p>
          <div className="mt-6 text-sm space-y-2">
            <div>📍 Cameroon</div>
            <div>📞 +237 6XX XXX XXX</div>
            <div>✉️ tinyhomes@company.com</div>
          </div>

          <div className="mt-6">
            <iframe title="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d198742.123!2d9.5!3d4.05!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDTCsDAyJzAwLjAiTiA5wrAwMScwMC4wIlc!5e0!3m2!1sen!2scm!4v1610000000000" width="100%" height="200" className="rounded" style={{border:0}} allowFullScreen="" loading="lazy"></iframe>
          </div>
        </div>

        <form onSubmit={handleBooking} className="bg-white p-6 rounded text-gray-900">
          <label className="block text-sm font-medium">Name</label>
          <input name="name" required className="mt-2 w-full p-2 border rounded" />
          <label className="block text-sm font-medium mt-4">Email or Phone</label>
          <input name="contact" required className="mt-2 w-full p-2 border rounded" />
          <label className="block text-sm font-medium mt-4">Message</label>
          <textarea name="message" rows="4" className="mt-2 w-full p-2 border rounded" />
          <div className="mt-4 flex items-center justify-between">
            <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded">Send request</button>
            <div className="text-sm text-gray-600">We reply within 48 hours</div>
          </div>
        </form>
      </div>
    </section>
  );

  const RentToOwn = ()=> (
    <section id="rent-to-own" className="py-12">
      <div className="max-w-4xl mx-auto px-6">
        <h2 className="text-2xl font-bold mb-4">Rent-to-Own Plans</h2>
        <p className="text-gray-600">Flexible plans to help you own your tiny home with manageable monthly payments.</p>
        <ul className="mt-4 list-disc list-inside text-gray-600">
          <li>Low down payment options (as low as 5%)</li>
          <li>Terms from 24 to 84 months</li>
          <li>Early payoff options with no penalty</li>
        </ul>
        <div className="mt-6">
          <a className="px-4 py-2 bg-indigo-600 text-white rounded" href="#contact" onClick={(e)=>{e.preventDefault(); window.location.hash='contact'}}>Apply for a plan</a>
        </div>
      </div>
    </section>
  );

  const HomeHero = ()=> (
    <section className="bg-white py-16">
      <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl font-extrabold">TinyNest Homes — Quality Tiny Homes Built for You</h1>
          <p className="mt-4 text-gray-600">Eco-friendly, customizable tiny homes for living, rentals, offices, or retreats.</p>
          <div className="mt-6 flex gap-4">
            <a className="px-5 py-3 bg-indigo-600 text-white rounded" href="#homes" onClick={(e)=>{e.preventDefault(); window.location.hash='homes'}}>Our models</a>
            <a className="px-5 py-3 border rounded" href="#contact" onClick={(e)=>{e.preventDefault(); window.location.hash='contact'}}>Get a quote</a>
          </div>
        </div>
        <div>
          <img src="https://images.unsplash.com/photo-1505691723518-36a43f3a5d9b?q=80&w=1400&auto=format&fit=crop" className="rounded-lg shadow w-full h-80 object-cover" />
        </div>
      </div>
    </section>
  );

  const Models = ()=> (
    <section id="homes" className="py-12 bg-gray-50">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-2xl font-bold mb-4">Models</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[1,2,3].map(i=>(
            <div key={i} className="bg-white rounded-lg shadow overflow-hidden">
              <img src={`https://images.unsplash.com/photo-1521790366062-3a8e9f7d0d3c?q=80&w=1200&auto=format&fit=crop`} className="w-full h-48 object-cover" />
              <div className="p-4">
                <h3 className="font-semibold">Model {i}</h3>
                <p className="text-sm text-gray-600 mt-2">Compact design with smart storage and optional loft.</p>
                <div className="mt-3 flex gap-2">
                  <button className="px-3 py-2 bg-indigo-600 text-white rounded" onClick={()=>window.location.hash='contact'}>Inquire</button>
                  <button className="px-3 py-2 border rounded" onClick={()=>galleryNext(1)}>View photos</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900 dark:text-gray-100">
      {/* NAV */}
      <header className="bg-white dark:bg-gray-800 shadow sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <a href="#home" className="font-bold text-lg" onClick={(e)=>{e.preventDefault(); window.location.hash='home'}}>TinyNest</a>
            <nav className="hidden md:flex gap-4 text-sm">
              <a href="#homes" onClick={(e)=>{e.preventDefault(); window.location.hash='homes'}}>Models</a>
              <a href="#features" onClick={(e)=>{e.preventDefault(); window.location.hash='features'}}>Features</a>
              <a href="#pricing" onClick={(e)=>{e.preventDefault(); window.location.hash='pricing'}}>Pricing</a>
              <a href="#contact" onClick={(e)=>{e.preventDefault(); window.location.hash='contact'}}>Contact</a>
            </nav>
          </div>

          <div className="flex items-center gap-3">
            <button title="Toggle dark" onClick={()=>setDark(d=>!d)} className="p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700">
              {dark ? <FaSun/> : <FaMoon/>}
            </button>
            <a className="hidden md:inline-block px-4 py-2 bg-indigo-600 text-white rounded" href="#contact" onClick={(e)=>{e.preventDefault(); window.location.hash='contact'}}>Get a quote</a>
            <button className="md:hidden" onClick={()=>setMobileOpen(o=>!o)}>☰</button>
          </div>
        </div>
        {mobileOpen && (
          <div className="md:hidden border-t bg-white dark:bg-gray-800 p-4">
            <a className="block py-2" href="#homes" onClick={(e)=>{e.preventDefault(); window.location.hash='homes'}}>Models</a>
            <a className="block py-2" href="#features" onClick={(e)=>{e.preventDefault(); window.location.hash='features'}}>Features</a>
            <a className="block py-2" href="#pricing" onClick={(e)=>{e.preventDefault(); window.location.hash='pricing'}}>Pricing</a>
            <a className="block py-2" href="#contact" onClick={(e)=>{e.preventDefault(); window.location.hash='contact'}}>Contact</a>
          </div>
        )}
      </header>

      <main className="flex-grow">
        {route==="home" && (
          <>
            <HomeHero />
            <Models />
            <section id="features" className="py-12">
              <div className="max-w-6xl mx-auto px-6">
                <h2 className="text-2xl font-bold mb-4">Features</h2>
                <div className="grid md:grid-cols-4 gap-6">
                  <div className="p-4 bg-white rounded shadow text-center">Eco materials</div>
                  <div className="p-4 bg-white rounded shadow text-center">Insulated & energy efficient</div>
                  <div className="p-4 bg-white rounded shadow text-center">Custom finishes</div>
                  <div className="p-4 bg-white rounded shadow text-center">Delivery & setup</div>
                </div>
              </div>
            </section>

            <Gallery />
            <Pricing />
            <Testimonials />
            <BookingForm />
          </>
        )}

        {route==="homes" && (
          <>
            <Models />
            <Gallery />
            <Pricing />
            <BookingForm />
          </>
        )}

        {route==="pricing" && <Pricing />}

        {route==="contact" && <BookingForm />}

        {route==="rent-to-own" && <RentToOwn />}
      </main>

      <footer className="bg-white dark:bg-gray-800 border-t py-6">
        <div className="max-w-6xl mx-auto px-6 text-center text-sm">
          © {new Date().getFullYear()} TinyNest Homes — Built with care.
        </div>
      </footer>

      {/* WhatsApp floating CTA */}
      <a href="https://wa.me/237600000000?text=Hi%20TinyNest%2C%20I%27m%20interested%20in%20a%20tiny%20home" target="_blank" rel="noreferrer"
         className="fixed right-4 bottom-4 z-50 shadow-lg">
        <div className="flex items-center gap-3 px-4 py-3 rounded-full bg-green-500 text-white">
          <FaWhatsapp />
          <span className="hidden sm:inline">Chat on WhatsApp</span>
        </div>
      </a>

      {/* Phone CTA */}
      <a href="tel:+237600000000" className="fixed left-4 bottom-4 z-50">
        <div className="p-3 rounded-full bg-indigo-600 text-white shadow-lg"><FaPhone/></div>
      </a>

      {/* Inline styles for simple gallery/testimonial visibility control */}
      <style>{`
        .gallery-item{display:none}
        .gallery-item.visible{display:block}
      `}</style>
    </div>
  );
}
